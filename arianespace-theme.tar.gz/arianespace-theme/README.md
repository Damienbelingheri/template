# Arianespace Theme

Ce projet contient les assets associés aux projets Arianespace. Les logos & les images pour décorer les écrans de login ou les headers d'application. Des feuilles de style CSS optionnelles sont également proposées pour les pages de login par défault ou pour appliquer des styles aux headers. Le but est d'avoir un repository d'images et de styles génériques pour être utilisés dans les différents projets Arianespace, peu importe les frameworks ou bibliothèques sur lesquels ils sont construits.



## Installation

Les fichiers du theme s'installent par le biais de `npm` ou `yarn`. Il est possible de spécifier directement l'archive associée à ce repository public comme ceci:
__NOTE__: Si l'installation bloque, il se peut que ce soit lié au fait que le certificat du serveur gitlab soit auto-signé. Dans ce cas, il conviendra de lancer `yarn config set "strict-ssl" false` pour ignorer les erreurs associées.

Avec yarn: 
```shell
$ yarn add https://ae-e-scm01.ad.arianespace.fr/arianespace/theme/-/archive/master/theme-master.tar.gz
```

Avec npm:
```shell
$ npm install https://ae-e-scm01.ad.arianespace.fr/arianespace/theme/-/archive/master/theme-master.tar.gz
```

Les fichiers seront alors instalés dans le répertoire `node_modules/ariane-theme` de votre application.


## Notes

Ce thème et les styles proposés ne contiennent __AUCUNE__ dépendance et tout y est complètement optionnel.
Le choix du framework CSS utilisé est libre et les styles se suffisent à eux mêmes.

## Usage 

L'utilisation dépend de la bibliothèque utilisée pour gérer les assets. Globalement, il suffit d'importer les styles & les images de la même façon que les autres modules npm.

Avec `Webpack Encore` par exemple, il suffira tout simplement d'importer les fichiers de styles dans son point d'entré JS

```js
import 'arianespace-theme/css/login.css';
import 'arianespace-theme/css/header.css';
```


## Styles proposés


### Exemple de page de login

Pré-requis : Le `body` doit porter la class `login` comme ceci : `<body class="login">`

```html
<html>
	<head>
		... les styles doivent être chargés ...
	</head>
	<body class="login">
	    <div class="login-box">
	        <img class="logo" />
	
	        <h1>Mon application <span>v1.0</span></h1>
	
	        <form id="login-form" action="###url d'authentification####" method="post">
				<div class="row">
			        <label for="username" class="label">Login</label>
			        <div class="input">
			            <input type="text" name="_username" id="username" placeholder="Nom d'utilisateur" />
			        </div>
			    </div>
			    <div class="row">
			        <label for="password" class="label">Mot de passe</label>
			        <div class="input">
			            <input type="password" name="_password" id="password" placeholder="Mot de passe" />
			        </div>
			    </div>

  	        	 <div class="error">Exemple d'erreur</div>
  	        	 
			    <div class="actions">
			        <button type="submit" class="button" id="_submit" name="_submit">Se connecter</button>
			    </div>
	        </form>
	    </div>
	</body>
</html>

```

Cette page ressemblera à ceci:

![](page_login.png)


### Décoration pour les headers d'application

Il suffit d'ajouter la classe `header-ae` sur une `div` pour que son fond soit un dégradé de bleu accompagné de l'éclat de soleil et des petits nuages.
Si ce header contient une image avec la classe `logo` comme ceci `<img class="logo" />` sont contenu sera remplacé par le logo Arianespace.


```html
<html>
	<head>...</head>
	<body>
		<div class="header-ae">
			<img class="logo" />
		</div>
	</body>
</hml>
```

Ce qui ressemblera à 

Cette page ressemblera à ceci:

![](header.png)


## Troubleshooting

### Gestion des SVG

Les SVG étant utilisés dans les feuilles de styles, ils ne devront pas être inlinés automatiquement. Ils devront être chargés par le file-loader et être donc dump dans le répertoire publique des assets.
Par exemple, si vous choisissez d'utiliser le `raw-loader` pour charger vos SVG, il faudra donc bien penser à exclurer les SVG de ce theme.

```
{
    test: /\.svg$/,
    exclude: [/node_modules/], 
    use: 'raw-loader'
}
```

